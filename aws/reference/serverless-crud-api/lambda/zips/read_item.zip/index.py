import os
import json
import boto3

table_name = os.environ.get("TABLE_NAME", "")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(table_name) # type: ignore

def lambda_handler(event, context):
    headers = {"Content-Type": "application/json"}

    if table_name == "":
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": "DynamoDB table name not set in environment variables"})
        }

    try:
        headers["Access-Control-Allow-Origin"] = "*"

        if 'pathParameters' not in event or 'id' not in event['pathParameters']:
            return {
                "statusCode": 400,
                "headers": headers,
                "body": json.dumps({"error": "Missing required path parameter: id"})
            }

        item_id = event['pathParameters']['id']

        response = table.get_item(Key={"id": item_id})

        if "Item" not in response:
            return {
                "statusCode": 404,
                "headers": headers,
                "body": json.dumps({"error": "Item not found"})
            }

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({"data": response["Item"]})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": str(e)})
        }



